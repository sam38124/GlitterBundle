"use strict";
glitter.webUrl = "http://192.168.43.219"
function onCreate() {
    glitter.changePage('page/HelloWorld.html','HelloWorld',true,{})
}