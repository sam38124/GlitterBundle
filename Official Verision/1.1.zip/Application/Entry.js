"use strict";
function onCreate() {
    glitter.changePage('page/HelloWorld.html','HelloWorld',true,{})
}